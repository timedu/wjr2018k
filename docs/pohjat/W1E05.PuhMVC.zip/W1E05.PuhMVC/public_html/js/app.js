
"use strict";

$(() => {

    const view = new View( $('#numerot') );
    const model = new Model(view);    
    const controller = new Controller(model, $('#nimi'), $('#numero'));
        
    $('#etsi').click(controller.haeNumerot);
    $('#lisaa').click(controller.lisaaNumero);
    view.asetaPoistaja(controller.poistaNumero);

});



