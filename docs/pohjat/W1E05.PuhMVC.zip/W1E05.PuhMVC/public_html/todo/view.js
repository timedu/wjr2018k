
"use strict";

//
//  +------------------------------------+
//  | View                               |
//  +------------------------------------+
//  | - jqNumerot                        |
//  | - poistaNumero                     |
//  +------------------------------------+
//  | + paivita(nimi, numerot)           |
//  | + asetaPoistaja(funktio)           |
//  +------------------------------------+
//


/*
 * Nimi: 
 * OpNro:
 */


function View(jqNumerot) {
    var poistaNumero = function(){};
    this.asetaPoistaja = function (funktio) {
        poistaNumero = funktio;
    };    
    this.paivita = function (nimi, numerot) {};  
}

