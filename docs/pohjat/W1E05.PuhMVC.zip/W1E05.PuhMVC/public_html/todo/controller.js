
"use strict";

//
//  +------------------------------------+
//  | Controller                         |
//  +------------------------------------+
//  | - model                            |
//  | - jqNimi                           |
//  | - jqNumero                         |
//  +------------------------------------+
//  | + haeNumerot()                     |
//  | + lisaaNumero()                    |
//  | + poistaNumero(e)                  |
//  +------------------------------------+
//


/*
 * Nimi: 
 * OpNro:
 */


function Controller(model, jqNimi, jqNumero) {
    this.haeNumerot = function () {};
    this.lisaaNumero = function () {};
    this.poistaNumero = function (e) {};
}


