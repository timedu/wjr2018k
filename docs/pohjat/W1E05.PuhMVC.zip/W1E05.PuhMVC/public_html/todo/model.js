
"use strict";

//
//  +------------------------------------+
//  | MODEL                              |
//  +------------------------------------+
//  | - view                             |                      
//  | - henkilot = {}                    |                      
//  +------------------------------------+
//  | + annaNumerot(nimi)                |
//  | + lisaaNumero(nimi, numero)        |
//  | + poistaNumero(nimi, numero)       |
//  +------------------------------------+
//


/*
 * Nimi: 
 * OpNro:
 */


function Model (view) {
    var henkilot = {};
    this.annaNumerot = function (nimi) {};
    this.lisaaNumero = function (nimi, numero) {};
    this.poistaNumero = function (nimi, numero) {};
};

