
/* global muistio, expect, Function, View */


/*
 * -------------------------------------------------------------------------
 * Rakenne
 * -------------------------------------------------------------------------
 */

describe('Puhelinmuistio - View (rakenne):', function () {

//    var view = new muistio.View();
    var view = new View();

    //

    it('muodostimen prototyyppi-attribuutilla ei ole ominaisuuksia', function () {
//        expect(Object.keys(muistio.View.prototype).length).toEqual(0);
        expect(Object.keys(View.prototype).length).toEqual(0);
    });

    // 

//    it('oliolla on asetaSpanNimi -metodi', function () {
//        expect(view.hasOwnProperty('asetaSpanNimi') && view.asetaSpanNimi instanceof Function).toBeTruthy();
//    });
//
//    it('oliolla on asetaUlNumerot -metodi', function () {
//        expect(view.hasOwnProperty('asetaUlNumerot') && view.asetaUlNumerot instanceof Function).toBeTruthy();
//    });


//    it('oliolla on asetaPoistonKasittelija -metodi', function () {
//        expect(view.hasOwnProperty('asetaPoistonKasittelija') && view.asetaPoistonKasittelija instanceof Function).toBeTruthy();
//    });
    it('oliolla on asetaPoistaja -metodi', function () {
        expect(view.hasOwnProperty('asetaPoistaja') && view.asetaPoistaja instanceof Function).toBeTruthy();
    });


    it('oliolla on paivita -metodi', function () {
        expect(view.hasOwnProperty('paivita') && view.paivita instanceof Function).toBeTruthy();
    });

    // 

    it('oliolla ei ole metodien lisäksi muita ominaisuuksia', function () {
//        expect(Object.keys(view).length).toEqual(4);
        expect(Object.keys(view).length).toEqual(2);
    });

});


describe('Puhelinmuistio - View (toiminta):', function () {

    /*
     * Testikäyttöliittymä
     */
    
//    var span = document.createElement('span');
//    var ul = document.createElement('ul');
    
    var jqNumerot = $('<div/>');
    

    /*
     * Testauksen kohde: muistio.View
     */

    var view;

    beforeEach(function () {
        
//        view = new muistio.View();
//        view.asetaSpanNimi(span);
//        view.asetaUlNumerot(ul);
//        // 
//        span.textContent = '';
//        ul.innerHTML = '';

        view = new View(jqNumerot);
        jqNumerot.find('*').remove();
        
    });

    /*
     * Testit
     */

//    it('päivittää nimen käyttöliittymään', function () {
//
//        var nimi = 'bart';
//        var numerot = [];
//
//        view.paivita(nimi, numerot);
//
//        expect(span.textContent).toEqual('bart');
//        expect(ul.querySelectorAll('*').length).toEqual(0);
//    });

//    it('rakentaa li-elementit puhelinnumeroille', function () {
    it('rakentaa rivit puhelinnumeroille', function () {

        var nimi = '';
        var numerot = ['111', '333'];
        view.paivita(nimi, numerot);

//        expect(ul.querySelectorAll('li').length).toEqual(2);                
        expect(jqNumerot.find('div.row').length).toEqual(2);                
    });


//    it('esittää puhelinnumerot li-elementeissä', function () {
    it('esittää puhelinnumerot riveillä', function () {

        var nimi = '';
        var numerot = ['111', '333'];

        view.paivita(nimi, numerot);

//        expect(ul.querySelector('li:first-child').textContent.substr(0,3)).toEqual('111');
//        expect(ul.querySelector('li:last-child').textContent.substr(0,3)).toEqual('333');                
        expect(jqNumerot.find('.row:first-child :nth-child(2)').text()).toEqual('111');
        expect(jqNumerot.find('.row:last-child :nth-child(2)').text()).toEqual('333');
    });


//    it('rakentaa poisto-napit li-elementteihin', function () {
    it('rakentaa poisto-napit riveille', function () {

        var nimi = '';
        var numerot = ['111', '333'];
        view.paivita(nimi, numerot);

//        expect(ul.querySelectorAll('li button').length).toEqual(2);
        expect(jqNumerot.find('.row div button').length).toEqual(2);
    });


    it('asettaa poisto-napille click-tapahtuman käsittelijän', function () {

        var nimi = '';
        var numerot = ['111'];
        
        var tulos;
        var f = function () {tulos = 'xyz';}; 

//        view.asetaPoistonKasittelija(f);
        view.asetaPoistaja(f);
        view.paivita(nimi, numerot);
        jqNumerot.find('button').click();
        
        // ***** tähän asti muokattu

//        expect(ul.querySelector('li button').onclick).toEqual(f);
        expect(tulos).toEqual('xyz');
    });


//    it('otsikoi poistonapit "X"-merkillä', function () {
    it('otsikoi poistonapit "x"-merkillä', function () {

        var nimi = '';
        var numerot = ['111', '333'];

        view.paivita(nimi, numerot);

//        expect(ul.querySelector('li:first-child').textContent.substr(3)).toEqual('X');
//        expect(ul.querySelector('li:last-child').textContent.substr(3)).toEqual('X');

        expect(jqNumerot.find('.row:first-child button').text()).toEqual('x');
        expect(jqNumerot.find('.row:last-child button').text()).toEqual('x');                        
    });

});
