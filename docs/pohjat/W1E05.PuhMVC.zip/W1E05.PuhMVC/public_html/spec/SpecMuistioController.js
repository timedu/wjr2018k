

/* global expect, Function, Controller */

/*
 * -------------------------------------------------------------------------
 * Rakenne
 * -------------------------------------------------------------------------
 */

describe('Puhelinmuistio - Controller (rakenne):', function () {

//    var controller = new muistio.Controller(null);
    var controller = new Controller(null);

    //

    it('muodostimen prototyyppi-attribuutilla ei ole ominaisuuksia', function () {
//        expect(Object.keys(muistio.Controller.prototype).length).toEqual(0);
        expect(Object.keys(Controller.prototype).length).toEqual(0);
    });

    // 

//    it('oliolla on asetaNimiInput -metodi', function () {
//        expect(controller.hasOwnProperty('asetaNimiInput') && controller.asetaNimiInput instanceof Function).toBeTruthy();
//    });
//
//    it('oliolla on asetaNumeroInput -metodi', function () {
//        expect(controller.hasOwnProperty('asetaNumeroInput') && controller.asetaNumeroInput instanceof Function).toBeTruthy();
//    });
    
    
    it('oliolla on haeNumerot -metodi', function () {
        expect(controller.hasOwnProperty('haeNumerot') && controller.haeNumerot instanceof Function).toBeTruthy();
    });

    it('oliolla on lisaaNumero -metodi', function () {
        expect(controller.hasOwnProperty('lisaaNumero') && controller.lisaaNumero instanceof Function).toBeTruthy();
    });
    
    it('oliolla on poistaNumero -metodi', function () {
        expect(controller.hasOwnProperty('poistaNumero') && controller.poistaNumero instanceof Function).toBeTruthy();
    });

    // 

    it('oliolla ei ole metodien lisäksi muita ominaisuuksia', function () {
//        expect(Object.keys(controller).length).toEqual(5);
        expect(Object.keys(controller).length).toEqual(3);
    });

});

/*
 * -------------------------------------------------------------------------
 * Rakenne
 * -------------------------------------------------------------------------
 */

describe('Puhelinmuistio - Controller (toiminta):', function () {

    /*
     * Testimalli
     */

    var model = {
        lisaaNumero: function (nimi, numero) {
            this.nimi = nimi;
            this.numero = numero;
        },
        poistaNumero: function (nimi, numero) {
            this.nimi = nimi;
            this.numero = numero;
        },
        annaNumerot: function (nimi) {
            this.nimi = nimi;
        }
    };

    /*
     * käyttöliittymäelementit
     */
    
    
//    var nimiInput = document.createElement('input');
//    var numeroInput = document.createElement('input');

    var jqNimi = $('<input/>');
    var jqNumero = $('<input/>');
            
    
    /*
     * testauksen kohde (muistio.Controller)
     */
    
    var controller;

    beforeEach(function () {
        
//        controller = new muistio.Controller(model);  
//        
//        controller.asetaNimiInput(nimiInput);
//        controller.asetaNumeroInput(numeroInput);    
        
        delete model.nimi;
        delete model.numero;
        
        controller = new Controller(model, jqNimi, jqNumero); 
        
                        
    });

    /*
     * testit
     */

    it('kutsuu mallin lisaaNumero-metodia trimmatuilla parametreilla', function () {

//        nimiInput.value = ' bart   ';
//        numeroInput.value = '  99-33 ';
        
        jqNimi.val(' bart   ');
        jqNumero.val('  99-33 ');
        
        
        controller.lisaaNumero();

        expect(model.nimi).toEqual('bart');
        expect(model.numero).toEqual('99-33');
    });

    it('ei kutsu mallin lisaaNumero-metodia tyhjillä parametreilla', function () {

//        nimiInput.value = '    ';
//        numeroInput.value = '    ';
        
        jqNimi.val('    ');
        jqNumero.val('    ');
        
//        var nimi = model.nimi;
//        var numero = model.numero;
        var nimi = model.nimi ='xyz';
        var numero = model.numero = '123';
                
        controller.lisaaNumero();

        expect(model.nimi).toEqual(nimi);
        expect(model.numero).toEqual(numero);
    });

//    it('kutsuu mallin poistaNumero-metodia', function () {
    it('kutsuu mallin poistaNumero-metodia trimmatuilla parametreilla', function () {
        
        // *** tästä eteenpäin ...
                
        var buttonPoista = document.createElement('button');
        
//        buttonPoista.dataset.nimi = ' bart   ';
//        buttonPoista.dataset.numero = '  99-33 ';

        $(buttonPoista).data('nimi', 'bart');
        $(buttonPoista).data('numero', '99-33');
                                
        var e = {};
        e.target = buttonPoista;
        
        controller.poistaNumero(e);
        
        expect(model.nimi).toEqual('bart');
        expect(model.numero).toEqual('99-33');
        
    });

    it('kutsuu mallin annaNumerot-metodia trimmatulla parametrilla', function () {

//        nimiInput.value = ' bart   ';  
        jqNimi.val(' bart   ');  
        
        controller.haeNumerot();
        
        expect(model.nimi).toEqual('bart');
    });

    it('ei kutsu mallin annaNumerot-metodia tyhjällä parametrilla', function () {

//        nimiInput.value = '    '; 
        jqNimi.val('    '); 
        
//        var nimi = model.nimi;        
        var nimi = model.nimi = 'xyz';        
        controller.haeNumerot();
        
        expect(model.nimi).toEqual(nimi);
    });

});