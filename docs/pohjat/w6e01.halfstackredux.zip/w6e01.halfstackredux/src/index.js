
import React from 'react';
import ReactDOM from 'react-dom';

import App from './App-0.js';

// import App from './todo/App-1.js';
// import App from './todo/App-2.js';
// import App from './todo/App-3.js';
// import App from './todo/App-4.js';
// import App from './todo/App-5.js';

ReactDOM.render(<App />, document.getElementById('root'));

