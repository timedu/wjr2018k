
import React from 'react';


const App = () => {

  return (
    <div>
      <div>HalfStack</div>
    </div>
  )
}

export default App

