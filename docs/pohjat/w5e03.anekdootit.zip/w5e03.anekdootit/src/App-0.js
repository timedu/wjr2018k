
import React from 'react';


class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      selected: 0
    }
  }

  render() {
    return (
      <div>{this.props.anecdotes[this.state.selected]}</div>
    )
  }
}

export default App

