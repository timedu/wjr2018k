
/* global Backbone */

let SenderView = Backbone.View.extend({


});


