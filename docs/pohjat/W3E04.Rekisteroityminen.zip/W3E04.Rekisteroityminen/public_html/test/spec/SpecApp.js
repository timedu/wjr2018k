
/* global expect, OPISKELIJA */

var
        APP = 'ValidatorApp',
        //CONTROLLER = 'BondController',
        TEMPLATE = '../todo/template.html';

describe(APP + ' / ' +OPISKELIJA.nimi, function () {

    var templateHtml;

    beforeAll(function () {
        templateHtml = $.ajax(TEMPLATE, {async: false}).responseText;
    });

    describe('template', function () {
        it('sisältää form-elementin', function () {
            var template = $(templateHtml);
            expect(template.find('form').length).toBe(1);
        });
    });

    describe('form', function () {

        var scope, tpl, form;


        beforeEach(function () {

            module(APP);

            inject(function ($compile, $rootScope, $controller) {
                scope = $rootScope.$new();
                tpl = $compile($(templateHtml))(scope);
            });

            form = scope.lomake;
            scope.$apply();
        });

        it('kelpoistaa käyttäjätunnuksen', function () {
            
            expect(form.kayttajatunnus.$valid).toBeFalsy();

            form.kayttajatunnus.$setViewValue('kk');            
            expect(form.kayttajatunnus.$valid).toBeFalsy();
            
            form.kayttajatunnus.$setViewValue('kkk');            
            expect(form.kayttajatunnus.$valid).toBeTruthy();
        });

        it('kelpoistaa salasanan', function () {

            expect(form.salasana.$valid).toBeFalsy();

            form.salasana.$setViewValue('kk');            
            expect(form.salasana.$valid).toBeFalsy();

            form.salasana.$setViewValue('012345678');            
            expect(form.salasana.$valid).toBeFalsy();
            
            form.salasana.$setViewValue('01234X678');            
            expect(form.salasana.$valid).toBeTruthy();
        });

        it('kelpoistaa salasanavarmistuksen', function () {

            expect(form.salasanaUudelleen.$valid).toBeFalsy();

            form.salasanaUudelleen.$setViewValue('01234X678');            
            expect(form.salasanaUudelleen.$valid).toBeFalsy();

            form.salasana.$setViewValue('01234X678');            
            expect(form.salasanaUudelleen.$valid).toBeTruthy();
        });

        it('kelpoistaa etunimen', function () {

            expect(form.etunimi.$valid).toBeFalsy();

            form.etunimi.$setViewValue('e');            
            expect(form.etunimi.$valid).toBeFalsy();
                        
            form.etunimi.$setViewValue('ee');            
            expect(form.etunimi.$valid).toBeTruthy();
        });

        it('kelpoistaa sukunimen', function () {

            expect(form.sukunimi.$valid).toBeFalsy();

            form.sukunimi.$setViewValue('s');            
            expect(form.sukunimi.$valid).toBeFalsy();
                        
            form.sukunimi.$setViewValue('ss');            
            expect(form.sukunimi.$valid).toBeTruthy();
        });

        it('kelpoistaa henkilötunnuksen', function () {

            expect(form.henkilotunnus.$valid).toBeFalsy();

            form.henkilotunnus.$setViewValue('h');            
            expect(form.henkilotunnus.$valid).toBeFalsy();
            
            form.henkilotunnus.$setViewValue('111111-222A');            
            expect(form.henkilotunnus.$valid).toBeFalsy();
            
            form.henkilotunnus.$setViewValue('111311-222K');            
            expect(form.henkilotunnus.$valid).toBeFalsy();
            
            form.henkilotunnus.$setViewValue('111111-222Y');            
            expect(form.henkilotunnus.$valid).toBeTruthy();                                    
        });

        it('kelpoistaa valintalaatikon "hyväksyn käyttöehdot"', function () {

            expect(form.hyvaksynKayttoehdot.$valid).toBeFalsy();
 
            form.hyvaksynKayttoehdot.$setViewValue(true);            
            expect(form.hyvaksynKayttoehdot.$valid).toBeTruthy();                                    
        });

        it('kelpoistaa lomakkeen', function () {

            var button = tpl.find('button');

            expect(button.is(':disabled')).toBeTruthy();
            expect(form.$valid).toBeFalsy();
            
            form.kayttajatunnus.$setViewValue('kkk');            
            expect(form.$valid).toBeFalsy();
            
            form.salasana.$setViewValue('01234X678');            
            expect(form.$valid).toBeFalsy();
            
            form.salasanaUudelleen.$setViewValue('01234X678');            
            expect(form.$valid).toBeFalsy();
            
            form.etunimi.$setViewValue('ee');            
            expect(form.$valid).toBeFalsy();
            
            form.sukunimi.$setViewValue('ss');            
            expect(form.$valid).toBeFalsy();
            
            form.henkilotunnus.$setViewValue('111111-222Y');            
            expect(form.$valid).toBeFalsy();
            
            form.hyvaksynKayttoehdot.$setViewValue(true);            
            expect(form.$valid).toBeTruthy();  
            
            expect(button.is(':disabled')).toBeFalsy();            
        });

    });
    
    xdescribe('TARKASTA SOVELLUSTA AJAMALLA', function () {
         it('esittää kenttäkohtaiset kelpoistusilmoitukset', function () {
            expect(true).toBeTruthy();                         
         });
        
    });
    

});

