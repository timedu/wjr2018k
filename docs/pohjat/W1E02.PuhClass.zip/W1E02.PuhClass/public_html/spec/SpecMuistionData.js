

/* global expect */

describe('Puhelinmuistion data:', function () {
    
    /*
     * sisältää samat testit kuin 'Puhelinmuistion käyttö' kuitenkin
     * siten, että testit perustuvat muistion _henkilot -attribuutin arvoon
     */
    
    var nimi_1 = 'mikke';
    var numero_11 = '044-33669933';
    var numero_12 = '231';

    var nimi_2 = 'matti';
    var numero_21 = '1111';

    var nimi_eioo = 'jaakko';
    var numero_eioo = '333';

    var muistio;

    beforeEach(function () {
        muistio = new Puhelinmuistio();
    });

    /*
     * numeroiden lisäys
     */

    it('ei alusta muistiota numeroilla', function () {
        expect(Object.keys(muistio._henkilot).length).toEqual(0);
    });

    it('lisää numeron henkilölle', function () {

        muistio.lisaaNumero(nimi_1, numero_11);

        expect(Object.keys(muistio._henkilot).length).toEqual(1);
        expect(muistio._henkilot[nimi_1].length).toEqual(1);
        expect(muistio._henkilot[nimi_1][0]).toEqual(numero_11);
    });

    it('ei lisää samaa numeroa kahteen kertaan', function () {

        muistio.lisaaNumero(nimi_1, numero_11);
        muistio.lisaaNumero(nimi_1, numero_11);

        expect(muistio._henkilot[nimi_1].length).toEqual(1);
    });

    it('lisää henkilölle useita numeroita', function () {

        muistio.lisaaNumero(nimi_1, numero_11);
        muistio.lisaaNumero(nimi_1, numero_12);

        expect(muistio._henkilot[nimi_1].length).toEqual(2);
        expect(muistio._henkilot[nimi_1]).toContain(numero_11);
        expect(muistio._henkilot[nimi_1]).toContain(numero_12);

    });

    it('ei lisää henkilön numeroa toiselle henkilölle', function () {
        muistio.lisaaNumero(nimi_1, numero_11);
        expect(Object.keys(muistio._henkilot).length).toEqual(1);
    });

    it('lisää numeroita monelle henkilölle', function () {

        muistio.lisaaNumero(nimi_1, numero_11);
        muistio.lisaaNumero(nimi_1, numero_12);
        muistio.lisaaNumero(nimi_2, numero_21);

        expect(Object.keys(muistio._henkilot).length).toEqual(2);

        expect(muistio._henkilot[nimi_1].length).toEqual(2);
        expect(muistio._henkilot[nimi_1]).toContain(numero_11);
        expect(muistio._henkilot[nimi_1]).toContain(numero_12);

        expect(muistio._henkilot[nimi_2].length).toEqual(1);
        expect(muistio._henkilot[nimi_2]).toContain(numero_21);

    });

    /*
     * numeroiden poisto
     */

    it('ei poista numeroa, jos hakuehto (nimi) ei toteudu', function () {

        muistio.lisaaNumero(nimi_1, numero_11);
        muistio.lisaaNumero(nimi_1, numero_12);

        muistio.poistaNumero(nimi_eioo, numero_12);

        expect(Object.keys(muistio._henkilot).length).toEqual(1);
        expect(muistio._henkilot[nimi_1].length).toEqual(2);
        expect(muistio._henkilot[nimi_1]).toContain(numero_11);
        expect(muistio._henkilot[nimi_1]).toContain(numero_12);

    });

    it('ei poista numeroa, jos hakuehto (numero) ei toteudu', function () {

        muistio.lisaaNumero(nimi_1, numero_11);
        muistio.lisaaNumero(nimi_1, numero_12);

        muistio.poistaNumero(nimi_1, numero_eioo);

        expect(Object.keys(muistio._henkilot).length).toEqual(1);
        expect(muistio._henkilot[nimi_1].length).toEqual(2);
        expect(muistio._henkilot[nimi_1]).toContain(numero_11);
        expect(muistio._henkilot[nimi_1]).toContain(numero_12);

    });

    it('poistaa numeron toteutuvilla hakuehdoilla', function () {

        muistio.lisaaNumero(nimi_1, numero_11);
        muistio.lisaaNumero(nimi_1, numero_12);

        muistio.poistaNumero(nimi_1, numero_12);

        expect(muistio._henkilot[nimi_1].length).toEqual(1);
        expect(muistio._henkilot[nimi_1]).toContain(numero_11);
        expect(muistio._henkilot[nimi_1]).not.toContain(numero_12);

    });

    it('poistaa viimeisenkin numeron muistiosta', function () {


        muistio.lisaaNumero(nimi_1, numero_11);
        muistio.lisaaNumero(nimi_1, numero_12);

        muistio.poistaNumero(nimi_1, numero_12);
        muistio.poistaNumero(nimi_1, numero_11);

        // nimi poistuu poistettaessa viimeinen nimeen liittyvä numero
        expect(Object.keys(muistio._henkilot).length).toEqual(0);

    });


    /*
     * huom
     */

    it('palauttaa luettelon, jonka kautta ei voi lisätä numeroa muistioon', function () {

        expect(muistio.annaNumerot(nimi_1)).not.toBe(muistio._henkilot[nimi_1]);

    });


});

