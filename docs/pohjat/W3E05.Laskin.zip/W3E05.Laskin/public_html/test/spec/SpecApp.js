
/* global expect, OPISKELIJA */

var
        APP = 'CalcApp',
        CONTROLLER = 'CalcController',
        TEMPLATE = '../todo/template.html';

describe(APP + ' / ' + OPISKELIJA.nimi, function () {

    var templateHtml;

    beforeAll(function () {
        templateHtml = $.ajax(TEMPLATE, {async: false}).responseText;
    });

    describe('template', function () {
        it('sisältää oletetut elementit', function () {
            var tpl = $(templateHtml);
            expect(tpl.find('*').length).toBe(11);
            expect(tpl.find('h1').length).toBe(1);
            expect(tpl.find('p').length).toBe(3);
            expect(tpl.find('input').length).toBe(2);
            expect(tpl.find('span').length).toBe(1);
            expect(tpl.find('button').length).toBe(4);

        });
    });

    describe('view', function () {

        var scope, controller, tpl;


        beforeEach(function () {

            module(APP);

            inject(function ($compile, $rootScope, $controller) {

                scope = $rootScope.$new();
                tpl = $compile($(templateHtml))(scope);
                controller = $controller(CONTROLLER, {
                    $scope: scope
                });
            });

        });

        it('alustaa operandit nolliksi', function () {

            scope.$digest();

            expect(tpl.find('#luku1').val()).toBe('0');
            expect(tpl.find('#luku2').val()).toBe('0');
        });

        it('de-aktivoi jakolaskun (napin), jos jakaja on nolla, \n\
muiden nappien ollessa aktiivisia', function () {

            tpl.find('#luku1').val(1).trigger('input');
            tpl.find('#luku2').val(0).trigger('input');

            expect(tpl.find('button:disabled').length).toBe(1);
            expect(tpl.find('button:disabled').attr('id')).toBe('jaa');
        });

        it('aktivoi kaikki napit, jos molemmat operandit ovat nollasta \n\
poikkeavia kokonaislukuja', function () {

            tpl.find('#luku1').val(2).trigger('input');
            tpl.find('#luku2').val(2).trigger('input');

            expect(tpl.find('button:disabled').length).toBe(0);
        });

        it('de-aktivoi kaikki napit, jos operandi ei ole kokonaisluku', function () {

            tpl.find('#luku1').val('').trigger('input');
            tpl.find('#luku2').val(2).trigger('input');

            expect(tpl.find('button:disabled').length).toBe(4);

            tpl.find('#luku1').val('1X').trigger('input');

            expect(tpl.find('button:disabled').length).toBe(4);
        });


        it('esittää laskutoimitusten tulokset oikein', function () {

            tpl.find('#luku1').val(4).trigger('input');
            tpl.find('#luku2').val(2).trigger('input');

            tpl.find('#summaa').trigger('click');
            expect(tpl.find('#tulos').text()).toBe('6');

            tpl.find('#vahenna').trigger('click');
            expect(tpl.find('#tulos').text()).toBe('2');

            tpl.find('#kerro').trigger('click');
            expect(tpl.find('#tulos').text()).toBe('8');

            tpl.find('#jaa').trigger('click');
            expect(tpl.find('#tulos').text()).toBe('2');
        });

    });

});

