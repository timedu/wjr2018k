
import React from 'react';

// 
// Nimi:
// OpNro:
//

const App = () => {  
  return (
    <div>
      <div>App</div>
    </div>
  )
}

export default App
