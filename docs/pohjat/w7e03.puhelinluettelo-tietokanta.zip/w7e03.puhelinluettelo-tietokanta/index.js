
const mongoose = require('mongoose')
const url = require('./db-config')
mongoose.connect(url)

// 
// Nimi: 
// Opnro: 
// 

