

/* global TodoApp */

//
var OPISKELIJA = {
    nimi: 'N.N.',
    numero: '999999'
};
//

TodoApp.controller('TodoController', function ($scope, InitialData) {

    $scope.todos = InitialData.get();
    $scope.newTask = '';

    // ...


});
