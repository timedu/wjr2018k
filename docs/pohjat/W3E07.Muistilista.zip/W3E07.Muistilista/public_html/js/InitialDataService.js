
/* global TodoApp */

TodoApp.service('InitialData', function () {
    this.get = function () {
        return [
            {
                task: 'Opiskele Angularia',
                priority: 1,
                done: false
            },
            {
                task: 'Käy kaupassa',
                priority: 3,
                done: true
            },
            {
                task: 'Ruoki koira',
                priority: 2,
                done: true
            }
        ].slice();
    };
});
