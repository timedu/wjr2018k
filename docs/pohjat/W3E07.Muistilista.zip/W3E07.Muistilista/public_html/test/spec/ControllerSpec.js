
/* global expect, spyOn */

describe('TodoController', function () {
    
    //
    // AngularJS-kontrollerin testauksesta:
    // - https://docs.angularjs.org/guide/controller#testing-controllers
    // - https://docs.angularjs.org/guide/unit-testing#testing-a-controller
    // (noudatettu ensimmäisen viitteen osoittamaa käytäntöä)
    //
    
    var $scope;

    beforeEach(module('TodoApp'));

    beforeEach(inject(function ($rootScope, $controller) {
        $scope = $rootScope.$new();
        $controller('TodoController', {$scope: $scope});
    }));

    describe('add', function () {

        it('lisää uuden keskeneräisen tehtävän prioriteetilla 1', function () {

            let newTask = Math.random().toString();

            $scope.newTask = newTask;
            $scope.add();

            expect($scope.todos.length).toBe(4);
            expect($scope.todos[3].task).toBe(newTask);
            expect($scope.todos[3].priority).toBe(1);
            expect($scope.todos[3].done).toBe(false);
        });
    });


    describe('remove', function () {

        it('poistaa luettelosta parametrina annetun tehtävän (todo)', function () {

            let todoToRemove = $scope.todos[1];

            expect($scope.todos.includes(todoToRemove)).toBeTruthy();

            $scope.remove(todoToRemove);

            expect($scope.todos.length).toBe(2);
            expect($scope.todos.includes(todoToRemove)).toBeFalsy();
        });
    });


    describe('removeAll', function () {

        it('ei poista tehtäviä, jos varmistuskysymykseen (confirm) vastataan kielteisesti', function () {

            spyOn(window, 'confirm').and.returnValue(false);

            $scope.removeAll();

            expect(window.confirm).toHaveBeenCalled();
            expect($scope.todos.length).toBe(3);
        });

        it('poistaa tehtävät, jos varmistuskysymykseen (confirm) vastataan myönteisesti', function () {

            spyOn(window, 'confirm').and.returnValue(true);

            $scope.removeAll();

            expect(window.confirm).toHaveBeenCalled();
            expect($scope.todos.length).toBe(0);
        });
    });


    describe('toggleDone', function () {

        it('muuttaa keskeneräisen tehtävän valmiiksi', function () {

            let todo = $scope.todos[1];

            todo.done = false;

            $scope.toggleDone(todo);

            expect(todo.done).toBe(true);
        });

        it('muuttaa valmiin tehtävän keskeneräiseksi', function () {

            let todo = $scope.todos[1];

            todo.done = true;

            $scope.toggleDone(todo);

            expect(todo.done).toBe(false);
        });
    });

    describe('changePriority', function () {

        it('asettaa tehtävälle uuden prioriteetin (numeerisena)', function () {

            let todo = $scope.todos[1];

            let event = {
                target: $('<input/>').val(' 9  ')[0]
            };

            $scope.changePriority(todo, event);

            expect(todo.priority).toBe(9);

        });

        it('ei muuta prioriteettia, jos uusi arvo ei ole kelvollinen', function () {

            let todo = $scope.todos[1];
            let previousPriority = todo.priority;

            let event = {
                target: $('<input/>').val('ABC')[0]
            };

            $scope.changePriority(todo, event);

            expect(todo.priority).toBe(previousPriority);

        });

    });

    describe('setAllDone', function () {

        it('asettaa kaikki tehtävät tehdyksi', function () {

            $scope.setAllDone();

            expect($scope.todos.length).toBe(3);

            $scope.todos.forEach(function (todo) {
                expect(todo.done).toBe(true);
            });
        });

    });


    describe('todosDone', function () {

        it('asettaa alkuaineistoon perustuvan arvon', function () {

            $scope.$digest();

            expect($scope.todosDone).toBe(2);

        });

        it('kasvattaa arvoa yhdellä, kun luetteloon lisätään uusi valmis tehtävä', function () {

            $scope.$digest();

            let previousTodosDone = $scope.todosDone;

            $scope.todos.push({
                task: 'abc',
                priority: 1,
                done: true
            });

            $scope.$digest();

            expect($scope.todosDone).toBe(previousTodosDone + 1);

        });

    });

    describe('todosRemaining', function () {

        it('asettaa alkuaineistoon perustuvan arvon', function () {

            $scope.$digest();

            expect($scope.todosRemaining).toBe(1);

        });

        it('kasvattaa arvoa yhdellä, kun luetteloon lisätään uusi keskeneräinen tehtävä', function () {

            $scope.$digest();

            let previousTodosRemaining = $scope.todosRemaining;

            $scope.todos.push({
                task: 'abc',
                priority: 1,
                done: false
            });

            $scope.$digest();

            expect($scope.todosRemaining).toBe(previousTodosRemaining + 1);

        });

    });

});
