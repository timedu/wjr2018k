
/* global expect */

const Template = '../todo/TodoTemplate.html';

// AngularJS-näkymien testauksesta: 
// - http://zealake.com/2014/01/01/unit-test-your-angularjs-views/
// - https://github.com/larsthorup/angular-view
// - http://busypeoples.github.io/post/testing-components-angular-js/
// (tässä mukailtu edellisiä ja "ControllerSpec"-periaatteita)

describe('TodoTemplate', function () {

    var templateHtml;

    beforeEach(inject(function ($templateCache) {
        templateHtml = $templateCache.get(Template);
        if (!templateHtml) {
            templateHtml = $.ajax(Template, {async: false}).responseText;
            $templateCache.put(Template, templateHtml);
        }
    }));

    describe('template', function () {
        
        var template; 
        
        beforeEach(function(){
            template = $(templateHtml);                        
        });
        
        it('sisältää 4 div-elementtiä (huomioiden id-/class-attribuutit)', function () {

            expect(template.filter('div#todo-container').length).toBe(1);
            expect(template.find('div').length).toBe(3);                       
            expect(template.find('div#add-todo-container').length).toBe(1);
            expect(template.find('div.todo').length).toBe(1);
            expect(template.find('div#todo-footer').length).toBe(1);
        });
        
                
    });


    describe('view', function () {

        var $scope, view;

        beforeEach(inject(function ($compile, $rootScope) {

            $scope = $rootScope.$new();
            view = $compile(templateHtml)($scope);

            $scope.todos = [
                {
                    task: 'Opiskele Angularia',
                    priority: 1,
                    done: false
                },
                {
                    task: 'Käy kaupassa',
                    priority: 3,
                    done: true
                },
                {
                    task: 'Ruoki koira',
                    priority: 2,
                    done: true
                }
            ];
            $scope.$digest();

            this.sortedTodos = $scope.todos.slice().sort(function (a, b) {
                return a.priority - b.priority;
            });

        }));

        it('esittää muistilistan tehtävät', function () {

            expect(view.find('div.todo').length).toEqual($scope.todos.length);

            $scope.todos.forEach(function (todo) {
                expect(view.find('div.todo').text()).toContain(todo.task);
            });
        });

        it('esittää tehtävät prioriteetin mukaisessa järjestyksessä', function () {

            var todos = view.find('div.todo');
            expect(todos.length).toEqual($scope.todos.length);

            for (i = 0; i < todos.length; i++) {
                expect(Number($(todos[i]).find('input:text').val())).toEqual(this.sortedTodos[i].priority);
            }
        });

        it('esittää valmiit tehtävät tsekattuina ja yliviivattuina', function () {

            var todos = view.find('div.todo');
            expect(todos.length).toEqual($scope.todos.length);

            for (i = 0; i < todos.length; i++) {
                expect($(todos[i]).find('input:checkbox').is(':checked')).toBe(this.sortedTodos[i].done);
                expect($(todos[i]).find('span').is('.todo-done')).toBe(this.sortedTodos[i].done);
            }
        });

        it('esittää valmiiden ja keskeneräisten tehtävävien lukumäärän', function () {

            $scope.todosRemaining = 89;
            $scope.todosDone = 98;

            $scope.$digest();

            expect(Number(view.find('#todos-done').text())).toEqual($scope.todosDone);
            expect(Number(view.find('#todos-remaining').text())).toEqual($scope.todosRemaining);
        });

        it('välittää uuden tehtävän mallille', function () {

            let newTask = Math.random().toString();

            view.find('#add-todo-container input:text').val(newTask).trigger('input');

            expect($scope.newTask).toBe(newTask);

        });

        it('kutsuu add-funktiota, kun "Lisää tehtävä" -painiketta klikataan', function () {

            $scope.add = function () {};

            spyOn($scope, 'add');

            $(view.find('#add-todo-container button')[0]).trigger('click');

            expect($scope.add).toHaveBeenCalled();
        });

        it('kutsuu changePriority-funktiota, kun prioriteettia muutetaan', function () {

            $scope.changePriority = function () {};

            spyOn($scope, 'changePriority');

            let priorityInputElement = view.find('.todo input:text')[0];

            $(priorityInputElement).trigger('blur');

            expect($scope.changePriority).toHaveBeenCalled();
        });

        it('kutsuu changePriority-funktiota (parametreilla: todo, $event), kun prioriteettia muutetaan', function (done) {

            let priorityInputElement = view.find('.todo input:text')[0];

            $scope.changePriority = function (todo, event) {
                expect($scope.todos.includes(todo)).toBeTruthy();
                expect(event.target).toBe(priorityInputElement);
                done();
            };

            $(priorityInputElement).trigger('blur');
        });

        it('kutsuu remove-funktiota (parametrilla: todo), kun "Poista"-painiketta klikataan', function (done) {

            $scope.remove = function (todo) {
                expect($scope.todos.includes(todo)).toBeTruthy();
                done();
            };

            let firstTodoElement = view.find('.todo')[0];
            $(firstTodoElement).find('button.remove-todo').trigger('click');
        });


        it('kutsuu setAllDone-funktiota, kun "Merkkaa kaikki tehdyksi" -painiketta klikataan', function () {

            $scope.setAllDone = function () {};
            spyOn($scope, 'setAllDone');

            view.find('button#mark-todos-done').trigger('click');

            expect($scope.setAllDone).toHaveBeenCalled();
        });

        it('kutsuu removeAll-funktiota, kun "Poista kaikki" -painiketta klikataan', function () {

            $scope.removeAll = function () {};
            spyOn($scope, 'removeAll');

            view.find('button#remove-todos').trigger('click');

            expect($scope.removeAll).toHaveBeenCalled();
        });


        it('huomioi yksikön ja monikon valmiiden ja keskeneräisten tehtävien lukumäärien esityksessä', function () {

            $scope.todosDone = 1;
            $scope.todosRemaining = 2;
            let yksikkoMonikko = /\stehtävä\s.*\stehtävää\s/;

            $scope.$digest();
            let footerText = view.find('#todo-footer')
                    .text() // poistetaan rivinvaihdot
                    .replace(/(\r\n|\n|\r)/gm, "");

            expect(yksikkoMonikko.test(footerText)).toBeTruthy();

            $scope.todosDone = 2;
            $scope.todosRemaining = 1;
            let monikkoYksikko = /\stehtävää\s.*\stehtävä\s/;

            $scope.$digest();
            footerText = view.find('#todo-footer')
                    .text() // poistetaan rivinvaihdot
                    .replace(/(\r\n|\n|\r)/gm, "");

            expect(monikkoYksikko.test(footerText)).toBeTruthy();
        });

    });

});

