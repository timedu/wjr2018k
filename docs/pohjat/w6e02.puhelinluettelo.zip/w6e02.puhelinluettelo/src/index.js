
import React from 'react';
import ReactDOM from 'react-dom';

import App from './App-0.js';

// import App from './todo/App-1.js';
// import App from './todo/App-2.js';
// import App from './todo/App-3.js';
// import App from './todo/App-4.js';
// import App from './todo/App-5.js';
//
// import App from './todo/App-6.js';
// import App from './todo/App-7.js';
// import App from './todo/App-8.js';
// import App from './todo/App-9.js';
// import App from './todo/App-10.js';
//
// import App from './todo/App-11.js';
// import App from './todo/App-12.js';

ReactDOM.render(<App />, document.getElementById('root'));

