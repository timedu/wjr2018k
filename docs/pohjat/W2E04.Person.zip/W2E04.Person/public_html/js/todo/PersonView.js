
/* global Backbone, Handlebars */

//
// Nimi:
// OpNro:
// 

function PersonView(){}

