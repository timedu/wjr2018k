
/* global Backbone */

//
// Nimi:
// OpNro:
// 

function PersonModel(){}

