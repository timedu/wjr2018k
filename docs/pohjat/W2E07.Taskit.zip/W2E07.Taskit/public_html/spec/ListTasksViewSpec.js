
/* global expect, sinon */

describe("ListTasksView", function () {

    beforeEach(function () {

        $('body').append('\
<section id="list-tasks"></section>                                 \
<script id="list-tasks-template" type="text/x-handlebars-template"> \
    <h2>Tasks</h2>                                                  \
    {{#each tasks}}                                                 \
    <p data-id="{{id}}">{{title}} (done: {{completed}})</p>         \
    {{/each}}                                                       \
</script>                                                           \
        ');
        this.taskCollection = new TaskCollection();
        this.listTasksView = new ListTasksView({collection: this.taskCollection});
    });

    afterEach(function () {
        this.listTasksView.remove();
        this.taskCollection.remove();
        $('#add-task').remove();
    });


    //
    // Toiminta
    // 

    describe("Toiminta", function () {

        it("ei päivitä käyttöliittymää alustuksen yhteydessä", function () {
            expect($('#list-tasks *').length).toBe(0);
        });

        it("päivittää käyttöliittymän, kun kokoelmaan lisätään malli", function () {

            this.taskCollection.add({id: 0, title: 'task-0', completed: false});

            expect($('#list-tasks p').length).toBe(1);
            expect($('#list-tasks p').text()).toContain('task-0');
        });

        it("päivittää käyttöliittymän, kun kokoelman sisältämää mallia muutetaan", function () {

            this.taskCollection.add({id: 0, title: 'task-0', completed: false});

            let task = this.taskCollection.at(0);

            task.set('completed', true);

            expect($('#list-tasks p').length).toBe(1);
            expect($('#list-tasks p').text()).toContain('true');
        });

        it("muuttaa kokoelman sisältämää mallia, kun malliin liittyvää elementtiä klikataan", function () {

            this.taskCollection.add({id: 0, title: 'task-0', completed: false});
            this.taskCollection.add({id: 1, title: 'task-1', completed: false});
            this.taskCollection.add({id: 2, title: 'task-2', completed: false});

            $('#list-tasks p:nth-of-type(2)').click();

            expect(this.taskCollection.length).toBe(3);

            let task1 = this.taskCollection.at(1);
            let task2 = this.taskCollection.at(2);

            expect(task1.get('completed')).toBe(true);
            expect(task2.get('completed')).toBe(false);
        });

    });


    //
    // Rakenne
    // 

    describe("Rakenne", function () {
        it("sisältää oikean juurielementin", function () {
            expect($(this.listTasksView.el)[0]).toBe($('#list-tasks')[0]);
        });
    });


    //
    // Viittaukset
    //

    describe("Viittaukset", function () {

        let sandbox = sinon.createSandbox();

        afterEach(function () {
            sandbox.restore();
        });

        it("kutsuu template-metodia kerran, kun sivulla olevaa 'p'-elementtiä klikataan ", function () {

            this.taskCollection.add({id: 0, title: 'task-0', completed: false});

            sandbox.spy(this.listTasksView, "template");

            $('#list-tasks p:first-of-type').click();

            expect(this.listTasksView.template.callCount).toBe(1);

        });

        it("kutsuu template-metodia, kun kokoelmaan lisätään malli", function () {
            
            sandbox.spy(this.listTasksView, "template");

            this.taskCollection.add({id: 0, title: 'task-0', completed: false});

            expect(this.listTasksView.template.called).toBe(true);

        });

    });

});