
/* global expect, sinon */

describe("AddTaskView", function () {

    beforeEach(function () {

        $('body').append('          \
        <section id="add-task">     \
            <h2>Add task:</h2>      \
            <input/>                \
        </section>                  ');

        this.taskCollection = new TaskCollection();
        this.addTaskView = new AddTaskView({collection: this.taskCollection});
    });

    afterEach(function () {
        this.addTaskView.remove();
        this.taskCollection.remove();
        $('#add-task').remove();
    });


    //
    // Toiminta
    // 

    describe("Toiminta", function () {

        it("tallettaa mallin kokoelmaan", function () {

            this.taskCollection.add({
                id: 0,
                title: 'task-0',
                completed: false
            });

            this.taskCollection.add({
                id: 1,
                title: 'task-1',
                completed: false
            });

            let keypress = $.Event("keypress", {keyCode: 13, which: 13});

            $('#add-task input').val('task-title');
            $('#add-task input').trigger(keypress);

            expect(this.taskCollection.length).toBe(3);

            let task = this.taskCollection.toJSON()[2];

            expect(task.id).toBe(2);
            expect(task.title).toBe('task-title');
            expect(task.completed).toBe(false);

        });

    });


    //
    // Rakenne
    // 

    describe("Rakenne", function () {
        
        it("sisältää oikean juurielementin", function () {

            expect($(this.addTaskView.el)[0]).toBe($('#add-task')[0]);

        });

    });


    //
    // Viittaukset
    // 

    describe("Viittaukset", function () {

        beforeEach(function () {
            sinon.spy(this.addTaskView, "$");
        });

        afterEach(function () {
            this.addTaskView.$.restore();
        });

        it("käyttää viitauksessa dokumenttiin metodia 'this.$'", function () {

            let keypress = $.Event("keypress", {keyCode: 13, which: 13});

            $('#add-task input').val('task-title');
            $('#add-task input').trigger(keypress);

            expect(this.addTaskView.$.calledOnce).toBe(true);

        });

    });

});