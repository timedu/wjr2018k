
/* global Backbone */


// 
// Nimi: 
// OpNro: 
//


let AddTaskView = Backbone.View.extend({



});

