
/* global Backbone, Handlebars  */


// 
// Nimi: 
// OpNro: 
//


let ListTasksView = Backbone.View.extend({



});
