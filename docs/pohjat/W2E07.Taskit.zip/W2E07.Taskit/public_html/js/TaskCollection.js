
/* global Backbone */


/*
 * TaskModel
 */

//let TaskModel = Backbone.Model.extend();


/*
 * TaskCollection
 */

let TaskCollection = Backbone.Collection.extend({
//    model: TaskModel
    model: Backbone.Model.extend()
});

