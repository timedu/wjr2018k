
/* global Backbone */

let ClockModel = Backbone.Model.extend({
    incTime: function(){
        this.set('time', this.get('time') + 1);
    }
});

