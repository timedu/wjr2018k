
/* global Backbone */


//
// Nimi:
// OpNro:
//

let TaskCollection = Backbone.Collection.extend({    
    
    model: Backbone.Model.extend()
    
});

