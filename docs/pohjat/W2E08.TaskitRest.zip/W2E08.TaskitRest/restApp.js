
const express = require('express');
const app = express();

const bodyParser = require('body-parser');
app.use(bodyParser.json()); 

app.use(express.static('public'));

/*
 * Initial data
 */

const tasks = [
    {
        id: 0,
        title: 'readings',
        completed: true
    },
    {
        id: 1,
        title: 'homeworks',
        completed: false
    }
];

/*
 * GET all
 */

app.get('/tasks', (req, res) => {
    
    console.log(req.method, req.path, tasks);
    
    res.json(tasks);
});

/*
 * POST new
 */

app.post('/tasks', (req, res) => {     
    
    console.log(req.method, req.path, req.body); 
    
    let newTask = req.body;
    newTask.completed = false;
    newTask.id = tasks.length;    
    tasks.push(newTask); 
    
    res.status(201).json(newTask);
});

/*
 * GET one
 */

app.get('/tasks/:id', (req, res) => {
    
    console.log(req.method, req.path);
    
    res.json(tasks[req.params.id]);
});

/*
 * Update status (PUT)
 */

app.put('/tasks/:id', (req, res) => {
    
    console.log(req.method, req.path, req.body);  
    
    tasks[req.params.id] = req.body; 
    
    res.status(204).end();
});

/*
 * Start server
 */

app.listen(3000, () => {
    console.log('app listening on localhost:3000');
});
