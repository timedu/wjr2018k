
/* global expect, Function, puhelinmuistio */

describe('Puhelinmuistion rakenne', function () {

    it('puhelinmuistio-oliolla on lisaaNumero -metodi', function () {
        expect(puhelinmuistio.hasOwnProperty('lisaaNumero') && puhelinmuistio.lisaaNumero instanceof Function).toBeTruthy();
    });

    it('puhelinmuistio-oliolla on annaNumerot -metodi', function () {
        expect(puhelinmuistio.hasOwnProperty('annaNumerot') && puhelinmuistio.annaNumerot instanceof Function).toBeTruthy();
    });

    it('puhelinmuistio-oliolla on poistaNumero -metodi', function () {
        expect(puhelinmuistio.hasOwnProperty('poistaNumero') && puhelinmuistio.poistaNumero instanceof Function).toBeTruthy();
    });

    it('puhelinmuistio-oliolla on _reset -metodi', function () {
        expect(puhelinmuistio.hasOwnProperty('_reset') && puhelinmuistio._reset instanceof Function).toBeTruthy();
    });

    it('puhelinmuistio-oliolla ei ole metodien lisäksi muita ominaisuuksia', function () {                
        expect(Object.keys(puhelinmuistio).length).toEqual(4);
    });        

    it('puhelinmuistio-olio on "välitön" Object', function () {                
        expect(puhelinmuistio.constructor).toBe(Object);
    });        
            
});
