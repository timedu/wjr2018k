
"use strict";
/*
 * Nimi: 
 * OpNro:
 */

var puhelinmuistio;

