/* global puhelinmuistio */

"use strict";

$(() => {

//    const muistio = new Puhelinmuistio();
    const muistio = puhelinmuistio;

    /**
     * Esittää nimi-kenttään annetun henkilön puhelinnumerot sivulla,
     * kun etsi-painiketta klikataan
     */
    $('#etsi').click(() => {
        esitaNumerot($('#nimi').val().trim());
    });


    /**
     * Lisää puhelinmuistioon nimi-kenttään syötetylle henkilölle 
     * numero-kenttään syötetyn puhelinnumeron ja esittää henkilön
     * puhelinnumerot sivulla
     */
    $('#lisaa').click(() => {
        muistio.lisaaNumero($('#nimi').val().trim(), $('#numero').val().trim());
        esitaNumerot($('#nimi').val().trim());
    });


    /**
     * Hakee parametrina annetun henkilön numerot ja rakentaa niiden
     * esittämiseen tarvittavat elementit sivulle
     * @param {String} nimi 
     */
    let esitaNumerot = nimi => {

        $('#numerot *').remove();

        muistio.annaNumerot(nimi).forEach(numero => {

            const row = $('<div/>').addClass('row mt-1').appendTo('#numerot');

            $('<div/>').addClass('col-sm-5').text(nimi).appendTo(row);
            $('<div/>').addClass('col-sm-5').text(numero).appendTo(row);
            $('<div/>').addClass('col-sm').appendTo(row);

            $('<button/>').addClass('btn btn-danger btn-sm')
                    .data('nimi', nimi).data('numero', numero)
                    .appendTo(row.find(':last-child'))           
                    .text('x')
                    /**
                     * Poistaa puhelinmuisiosta numeron, jonka tiedot on 
                     * liitetty klikattuun painikkeeseen
                     * @param {Event} e
                     */
                    .click(e => {
                muistio.poistaNumero($(e.target).data('nimi'), $(e.target).data('numero'));
                esitaNumerot($(e.target).data('nimi'));
            });
        });
    };
});
