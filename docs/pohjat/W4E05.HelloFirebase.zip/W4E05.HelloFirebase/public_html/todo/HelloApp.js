
/* global firebase */

//
// Nimi:
// OpNro: 
//

let HelloApp = angular.module("HelloApp", ["firebase"]);

HelloApp.config(function () {

});


HelloApp.controller("HelloController", function ($scope, $firebaseObject) {

});

