
/* global expect */

var APP = 'HelloFirebase';

describe(APP, function () {

    xdescribe('TARKASTA SOVELLUS SITÄ AJAMALLA', function () {


    });

});

