
const PuhApp = angular.module('PuhApp', ['ngRoute']);

PuhApp.value('InitialData', {
    bart: ['111', '222', '333'],
    ned: ['444', '555']
});

