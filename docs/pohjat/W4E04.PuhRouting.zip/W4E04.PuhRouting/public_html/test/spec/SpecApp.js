
/* global expect */

var APP = 'PuhRouting';

describe(APP, function () {

    xdescribe('TARKASTA SOVELLUS SITÄ AJAMALLA', function () {


    });

});

