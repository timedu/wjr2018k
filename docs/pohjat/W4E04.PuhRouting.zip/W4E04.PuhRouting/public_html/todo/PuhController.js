

/* global PuhApp */

"use strict";

//
// Nimi: 
// OpNro:
//

PuhApp.controller('PuhController', function ($scope, PuhService, $routeParams) {


});

