
/* global PuhApp */

"use strict";

//
// Nimi: 
// OpNro:
//

PuhApp.controller('AddController', function ($scope, PuhService, $location, $routeParams) {


});

