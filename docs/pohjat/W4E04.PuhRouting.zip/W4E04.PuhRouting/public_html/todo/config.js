
/* global PuhApp */

"use strict";

//
// Nimi: 
// OpNro:
//

PuhApp.config(function ($routeProvider) {


});

