
/* global PuhApp */

"use strict";

//
// Nimi: 
// OpNro:
//

PuhApp.controller('RemoveController', function ($scope, PuhService, $location, $routeParams) {



});

