
/* global PuhApp */

"use strict";

//
// Nimi: 
// OpNro:
//

PuhApp.controller('AddController', function ($scope, Puh, $location, $routeParams) {

    console.log('AddController');


});

