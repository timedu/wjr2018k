

/* global PuhApp */

"use strict";

//
// Nimi: 
// OpNro:
//

PuhApp.controller('PuhController', function ($scope, $routeParams, Puh, $location) {

    console.log('PuhController');



});

