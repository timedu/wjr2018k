
/* global firebase */


/*
 * ----------------------------------------------------------------------
 * Angular-moduuli
 * ----------------------------------------------------------------------
 */

const PuhApp = angular.module('PuhApp', ['ngRoute', 'firebase']);

/*
 * ----------------------------------------------------------------------
 * Firebase-projektin tunnisteet
 * ----------------------------------------------------------------------
 */

PuhApp.config(function () {
    firebase.initializeApp({
        apiKey: "***",
        authDomain: "***",
        databaseURL: "***",
        storageBucket: "***",
        messagingSenderId: "***"
    });
});

/*
 * ----------------------------------------------------------------------
 * Tunnisteet Firebasen autentikointia varten
 * ----------------------------------------------------------------------
 */

PuhApp.constant('FirebaseUser', {
    email: '***',
    password: '***'
});

/*
 * ----------------------------------------------------------------------
 * Muodostaa palvelun (funktion), joka palauttaa henkilön numerolistaan
 * viittaavan $firebaseArray-objektin - kutsu: Puh(nimi)
 * ----------------------------------------------------------------------
 */

PuhApp.factory("Puh", function ($firebaseArray) {
    
    let puh;    
    
    return function (nimi) {    

        if (puh !== undefined && !puh.$isDestroyed) {
            puh.$destroy();
        }         
        if(!nimi) return;
        
        let ref = firebase.database().ref(nimi); 
        puh =  $firebaseArray(ref);
        
        return puh;
    };    
});

/*
 * ----------------------------------------------------------------------
 * Kirjautumiseen liittyvät toiminnot
 * ----------------------------------------------------------------------
 * Asettaa näkyvyysalueelle (rootScope) seuraavat tunnisteet 
 * + signedIn   // onko käyttäjä kirjautunut
 * + signIn()   // kirjautuminen sisään
 * + signOut()  // kirjautuminen ulos
 * ----------------------------------------------------------------------
 */

PuhApp.run(function ($rootScope, $location, $firebaseAuth, FirebaseUser, Puh) {

    // --
    // Kirjautuminen sisään    
    $rootScope.signIn = function () {
        $firebaseAuth().$signInWithEmailAndPassword(
                FirebaseUser.email,
                FirebaseUser.password)
                .catch(function (error) {
                    console.log("Login failed", error.code, error.message);
                });
    };

    // --
    // Kirjautuminen ulos
    $rootScope.signOut = $firebaseAuth().$signOut;

    // --
    // Toiminta, kun käyttäjä vaihtuu  
    $firebaseAuth().$onAuthStateChanged(function (user) {

        $rootScope.signedIn = !!user;
        
        if(!$rootScope.signedIn){
             Puh();
             $location.path('/');
        }        
        console.log('User signed', $rootScope.signedIn ? 'in.' : 'out.');
    });

    // --
    // Toiminta, kun pyritään kirjautumatta tiettyihin polkuihin
    $rootScope.$on("$routeChangeError", function (event, next, previous, error) {
        console.log(error);
        if (error === "AUTH_REQUIRED") {
            $location.path("/");
        }
    });
});

/*
 * ----------------------------------------------------------------------
 * Reititys
 * ----------------------------------------------------------------------
 */

PuhApp.config(function ($routeProvider) {
    $routeProvider
            .when('/', {
                controller: 'PuhController',
                templateUrl: 'todo/search.html'
            })
            .when('/:nimi', {
                controller: 'PuhController',
                templateUrl: 'todo/search.html',
                resolve: {
                    currentAuth: function ($firebaseAuth) {
                        return $firebaseAuth().$requireSignIn();
                    }
                }
            })
            .when('/:nimi/add', {
                controller: 'AddController',
                templateUrl: 'view/add.html',
                resolve: {
                    currentAuth: function ($firebaseAuth) {
                        return $firebaseAuth().$requireSignIn();
                    }
                }
            })
            .when('/:nimi/remove/:key/:numero', {
                controller: 'RemoveController',
                templateUrl: 'view/remove.html',
                resolve: {
                    currentAuth: function ($firebaseAuth) {
                        return $firebaseAuth().$requireSignIn();
                    }
                }
            })
            .otherwise({
                redirectTo: '/'
            });
});

