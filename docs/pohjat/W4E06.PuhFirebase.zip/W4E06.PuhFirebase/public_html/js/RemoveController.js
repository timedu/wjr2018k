
/* global PuhApp */

"use strict";

PuhApp.controller('RemoveController', function (Puh, $scope, $location, $routeParams) {

    console.log('RemoveController');

    $scope.nimi = $routeParams.nimi;
    $scope.numero = $routeParams.numero;

    let key = $routeParams.key;    
    let puh = Puh($scope.nimi);

    $scope.remove = function () {
        puh.$remove(puh.$getRecord(key));
        $location.path('/' + $scope.nimi);
    };

    $scope.cancel = function () {
        $location.path('/' + $scope.nimi);
    };

});

