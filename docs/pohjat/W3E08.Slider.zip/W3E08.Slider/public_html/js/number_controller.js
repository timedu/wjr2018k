
/* global NumberApp */

NumberApp.controller('NumberController', function($scope){
	$scope.number = 10;
});