var NumberApp = angular.module('NumberApp', []);
