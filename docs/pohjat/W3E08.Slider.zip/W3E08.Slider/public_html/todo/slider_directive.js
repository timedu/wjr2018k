
/* global NumberApp */

//
// Nimi:
// OpNro: 
//

NumberApp.directive('slider', function () {
    
    return { };
});


