
/* global expect, puh, OPISKELIJA */

const APP = 'PuhAngular';

describe(`${APP} / ${OPISKELIJA.nimi}` , function () {

    describe('PuhController', function () {

        //
        // AngularJS-kontrollerin testauksesta: 
        // vrt. W3E07.Muistilista
        //  

        var $scope;

        beforeEach(module('PuhApp'));

        beforeEach(inject(function ($rootScope, $controller) {
            
            $scope = $rootScope.$new();
            $controller('PuhController', {$scope: $scope});

            puh._reset();
            puh.lisaaNumero('bart', 111);
            puh.lisaaNumero('bart', 222);
            puh.lisaaNumero('bart', 333);
        }));

        describe('watch', function () {

            it('esittää henkilön numerot', function () {

                $scope.nimi = 'bart';

                $scope.$digest();

                expect($scope.numerot.length).toBe(3);
                expect($scope.numerot.includes(222)).toBeTruthy();
            });

            it('ei esitä henkilölle toisen numeroita', function () {

                $scope.nimi = 'bart';
                $scope.$digest();

                $scope.nimi = 'ned';
                $scope.$digest();

                expect($scope.numerot.length).toBe(0);
            });

        });

        describe('add', function () {

            it('lisää muistioon numeron', function () {

                $scope.nimi = 'homer';
                $scope.uusiNumero = 555;

                $scope.add();

                let numerot = puh.annaNumerot('homer');

                expect(numerot.length).toBe(1);
                expect(numerot.includes(555)).toBeTruthy();
            });

            it('esittää lisätyn numeron', function () {

                $scope.nimi = 'homer';
                $scope.uusiNumero = 555;

                $scope.add();

                expect($scope.numerot.length).toBe(1);
                expect($scope.numerot.includes(555)).toBeTruthy();
            });

        });

        describe('remove', function () {

            it('poistaa muistiosta numeron', function () {

                $scope.remove('bart', 222);

                let numerot = puh.annaNumerot('bart');

                expect(numerot.length).toBe(2);
                expect(numerot.includes(222)).toBeFalsy();
                expect(numerot.includes(333)).toBeTruthy();
            });
            
            it('ei esitä poistettua numeroa', function () {

                $scope.remove('bart', 222);

                expect($scope.numerot.length).toBe(2);
                expect($scope.numerot.includes(222)).toBeFalsy();
                expect($scope.numerot.includes(333)).toBeTruthy();
            });

        });

    });

    xdescribe('Tarkasta sovellus myös sitä ajamalla', function () {

    });

});

