
const PuhApp = angular.module('PuhApp', []);
