
"use strict";

const puh = new function () {

    let henkilot = {};

    this.annaNumerot = function (nimi) {
        var numerot = Object.keys(henkilot).includes(nimi)
                ? henkilot[nimi].slice() : [];
        return numerot;
    };

    this.lisaaNumero = function (nimi, numero) {
        if (!Object.keys(henkilot).includes(nimi)) {
            henkilot[nimi] = [];
        }
        if (!henkilot[nimi].includes(numero)) {
            henkilot[nimi].push(numero);
        }
    };

    this.poistaNumero = function (nimi, numero) {

        if (!Object.keys(henkilot).includes(nimi)) {
            return; // (nimeä ei löydy)
        }

        if (!henkilot[nimi].includes(numero)) {
            return; // (numeroa ei löydy)
        }

        // poistetaan numero
        var index = henkilot[nimi].indexOf(numero);
        henkilot[nimi].splice(index, 1);

        // poistetaan nimi, jos ei ole enää numeroita
        if (henkilot[nimi].length < 1) {
            delete henkilot[nimi];
        }
    };
    
    this._reset = function(){henkilot={};};    
};


