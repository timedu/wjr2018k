
//
const OPISKELIJA = {
    nimi: 'N.N.',
    numero: '999999'
};
//

/* global puh, PuhApp */

"use strict";

PuhApp.controller('PuhController', function ($scope) {


    // ...

});

