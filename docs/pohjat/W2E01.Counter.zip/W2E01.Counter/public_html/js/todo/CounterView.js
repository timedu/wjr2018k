
/* global Backbone */

let CounterView = Backbone.View.extend({

});
