
import React from 'react';

// 
// Nimi:
// OpNro:
//


// class App extends React.Component {

//     render() {
//         return (
//             <div>
//                 <h2>anna palautetta</h2>
//                 <div>
//                     <button>hyvä</button>
//                     <button>neutraali</button>
//                     <button>huono</button>
//                 </div>
//                 <h2>statistiikka</h2>
//                 <div>
//                     <div>hyvä</div>
//                     <div>neutraali</div>
//                     <div>huono</div>
//                     <div>keskiarvo</div>
//                     <div>positiivisia</div>
//                 </div>
//             </div>
//         )
//     }
// }


export default App

