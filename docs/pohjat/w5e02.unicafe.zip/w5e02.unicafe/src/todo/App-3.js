
import React from 'react';

// 
// Nimi:
// OpNro:
//

// const Button = ...
// const Statistic = ...

// const Statistics = ... => {

//     return (
//         <div>
//             <Statistic ... />
//             <Statistic ... />
//             <Statistic ... />
//             <Statistic ... />
//             <Statistic ... />
//         </div>
//     )
// }

// class App extends React.Component {
//     ...
//     render() {
//         return (
//             <div>
//                 <h2>anna palautetta</h2>
//                 <div>
//                     <Button ... />
//                     <Button ... />
//                     <Button ... />
//                 </div>
//                 <h2>statistiikka</h2>
//                 <Statistics ... />
//             </div>
//         )
//     }
// }



export default App

