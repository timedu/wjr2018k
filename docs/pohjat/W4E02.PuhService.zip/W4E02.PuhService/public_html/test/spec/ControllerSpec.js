
/* global expect, jasmine */


describe('PuhController', function () {

    //
    // AngularJS-kontrollerin testauksesta: 
    // vrt. W3E07.Muistilista
    // 
    // Palveluja käyttävän kontrollerin testauksesta:  
    // https://peteschuster.com/2016/03/jasmine-testing-angular-controller-services/
    //

    var $scope, PuhService;

    beforeEach(module('PuhApp'));

    beforeEach(function () {                
        PuhService = jasmine.createSpyObj('PuhService', [
            'annaNumerot',
            'lisaaNumero',
            'poistaNumero'
        ]);
        module(function ($provide) {
            $provide.value('PuhService', PuhService);
        });
    });

    beforeEach(inject(function ($rootScope, $controller) {
        $scope = $rootScope.$new();
        $controller('PuhController', {$scope: $scope});
    }));

    describe('watch', function () {

        it('käyttää palvelua henkilön numeroiden hakuun', function () {

            $scope.nimi = 'bart';
            $scope.$digest();
            
            expect(PuhService.annaNumerot).toHaveBeenCalledWith('bart');
        });
    });

    describe('add', function () {

        it('käyttää palvelua numeron lisäämiseen ja numeroiden hakuun', function () {

            $scope.nimi = 'homer';
            $scope.uusiNumero = 555;

            $scope.add();

            expect(PuhService.lisaaNumero).toHaveBeenCalledWith('homer', 555);
            expect(PuhService.annaNumerot).toHaveBeenCalledWith('homer');
        });
    });


    describe('remove', function () {

        it('käyttää palvelua numeron poistoon ja numeroiden hakuun', function () {

            $scope.remove('bart', 222);

            expect(PuhService.poistaNumero).toHaveBeenCalledWith('bart', 222);
            expect(PuhService.annaNumerot).toHaveBeenCalledWith('bart');
        });

    });

});

xdescribe('Tarkasta sovellus myös kokonaisuutena sitä ajamalla', function () {

});


