
/* global expect */

describe('PuhService', function () {

    //
    // Periaate: https://docs.angularjs.org/guide/services#unit-testing
    // Testit: Tehtävä 1.1
    //

    let muistio;

    beforeEach(module('PuhApp'));

    beforeEach(function () {
        inject(function ($injector) {
            muistio = $injector.get('PuhService');
        });
    });

    describe('annaNumerot', function () {

        it('ei alusta muistiota numeroilla', function () {
            expect(muistio.annaNumerot('bart').length).toEqual(0);
        });

        it('palauttaa luettelon, jonka kautta ei voi lisätä numeroa muistioon', function () {

            muistio.lisaaNumero('bart', 111);
            muistio.annaNumerot('bart').push(222);

            expect(muistio.annaNumerot('bart').length).toEqual(1);
            expect(muistio.annaNumerot('bart')).not.toContain(222);

        });
    });

    describe('lisaaNumero', function () {

        it('lisää numeron henkilölle', function () {

            muistio.lisaaNumero('bart', 111);

            expect(muistio.annaNumerot('bart').length).toEqual(1);
            expect(muistio.annaNumerot('bart')).toContain(111);
        });

        it('ei lisää samaa numeroa kahteen kertaan', function () {

            muistio.lisaaNumero('bart', 111);
            muistio.lisaaNumero('bart', 111);

            expect(muistio.annaNumerot('bart').length).toEqual(1);

        });

        it('lisää henkilölle useita numeroita', function () {

            muistio.lisaaNumero('bart', 111);
            muistio.lisaaNumero('bart', 222);

            expect(muistio.annaNumerot('bart').length).toEqual(2);
            expect(muistio.annaNumerot('bart')).toContain(111);
            expect(muistio.annaNumerot('bart')).toContain(222);

        });

        it('ei lisää henkilön numeroa toiselle henkilölle', function () {
            muistio.lisaaNumero('bart', 111);
            expect(muistio.annaNumerot('ned').length).toEqual(0);
        });

        it('lisää numeroita monelle henkilölle', function () {

            muistio.lisaaNumero('bart', 111);
            muistio.lisaaNumero('bart', 222);
            muistio.lisaaNumero('ned', 333);

            expect(muistio.annaNumerot('bart').length).toEqual(2);
            expect(muistio.annaNumerot('bart')).toContain(111);
            expect(muistio.annaNumerot('bart')).toContain(222);

            expect(muistio.annaNumerot('ned').length).toEqual(1);
            expect(muistio.annaNumerot('ned')).toContain(333);

        });

    });

    describe('poistaNumero', function () {
        
        it('ei poista numeroa, jos hakuehto (nimi) ei toteudu', function () {

            muistio.lisaaNumero('bart', 111);
            muistio.lisaaNumero('bart', 222);

            muistio.poistaNumero('ned', 222);

            expect(muistio.annaNumerot('bart').length).toEqual(2);
            expect(muistio.annaNumerot('bart')).toContain(222);

        });

        it('ei poista numeroa, jos hakuehto (numero) ei toteudu', function () {

            muistio.lisaaNumero('bart', 111);
            muistio.lisaaNumero('bart', 222);

            muistio.poistaNumero('bart', 333);

            expect(muistio.annaNumerot('bart').length).toEqual(2);
            expect(muistio.annaNumerot('bart')).toContain(111);
            expect(muistio.annaNumerot('bart')).toContain(222);

        });

        it('poistaa numeron toteutuvilla hakuehdoilla', function () {

            muistio.lisaaNumero('bart', 111);
            muistio.lisaaNumero('bart', 222);

            muistio.poistaNumero('bart', 222);

            expect(muistio.annaNumerot('bart').length).toEqual(1);
            expect(muistio.annaNumerot('bart')).toContain(111);

        });

        it('poistaa viimeisenkin numeron muistiosta', function () {


            muistio.lisaaNumero('bart', 111);
            muistio.lisaaNumero('bart', 222);

            muistio.poistaNumero('bart', 222);
            muistio.poistaNumero('bart', 111);

            expect(muistio.annaNumerot('bart').length).toEqual(0);

        });

    });

});



