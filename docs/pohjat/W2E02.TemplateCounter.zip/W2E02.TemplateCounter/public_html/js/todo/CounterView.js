
/* global Backbone, Handlebars */


let CounterView = Backbone.View.extend({

    template: Handlebars.compile($('#counter-template').html())

});

