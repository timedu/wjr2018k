

/* global expect, Function, Puhelinmuistio */

describe('Puhelinmuistion rakenne', function () {

    it('sisältää Puhelinmuisto -muodostinfunktion', function () {
        expect(Puhelinmuistio instanceof Function).toBeTruthy();
    });

    it('muodostimen prototyyppi-attribuutilla ei ole ominaisuuksia', function () {                
        expect(Object.keys(Puhelinmuistio.prototype).length).toEqual(0);
    });

    var muistio = new Puhelinmuistio();

    it('muistio-olio on tyyppiä Puhelinmuistio', function () {
        expect(muistio instanceof Puhelinmuistio).toBeTruthy();
    });

    it('muistio-oliolla on lisaaNumero -metodi', function () {
        expect(muistio.hasOwnProperty('lisaaNumero') && muistio.lisaaNumero instanceof Function).toBeTruthy();
    });

    it('muistio-oliolla on annaNumerot -metodi', function () {
        expect(muistio.hasOwnProperty('annaNumerot') && muistio.annaNumerot instanceof Function).toBeTruthy();
    });

    it('muistio-oliolla on poistaNumero -metodi', function () {
        expect(muistio.hasOwnProperty('poistaNumero') && muistio.poistaNumero instanceof Function).toBeTruthy();
    });

    it('muistio-oliolla ei ole metodien lisäksi muita ominaisuuksia', function () {                
        expect(Object.keys(muistio).length).toEqual(3);
    });
    
});
