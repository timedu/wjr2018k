
"use strict";
/*
 * Nimi: 
 * OpNro:
 */


function Puhelinmuistio() {
    
}

