
/* global Backbone */


let NavigationView = Backbone.View.extend({

    el: 'header',

    events: {

        "click a:nth(0)": function (e) {
            Backbone.trigger('addEntry');
            e.preventDefault();
        },

        "click a:nth(1)": function (e) {
            Backbone.trigger('statistics');
            e.preventDefault();
        }
    }
});


