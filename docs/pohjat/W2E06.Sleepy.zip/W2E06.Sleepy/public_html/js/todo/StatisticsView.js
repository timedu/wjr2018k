
/* global Backbone, Handlebars */


let StatisticsView = Backbone.View.extend({

});

