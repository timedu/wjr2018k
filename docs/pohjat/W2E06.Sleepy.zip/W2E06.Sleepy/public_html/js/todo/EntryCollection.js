
/* global Backbone */


let EntryCollection = Backbone.Collection.extend({


});

