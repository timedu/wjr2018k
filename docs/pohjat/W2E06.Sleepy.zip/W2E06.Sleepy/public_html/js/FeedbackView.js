
/* global Backbone, Handlebars */

let FeedbackView = Backbone.View.extend({
        
    el: '#main',
    
    initialize: function () {
        Backbone.on('feedback', this.render, this);
    },
        
    template: Handlebars.compile($('#feedback-template').html()),

    render: function (message, type) {
        this.$el.html(this.template({
            message: message,
            type: type
        }));
    }
});

