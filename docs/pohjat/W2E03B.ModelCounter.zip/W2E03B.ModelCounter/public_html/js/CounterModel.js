
/* global Backbone */

let CounterModel = Backbone.Model.extend({
    inc: function () {
        this.set('counter', this.get('counter') + 1);
    }
});

