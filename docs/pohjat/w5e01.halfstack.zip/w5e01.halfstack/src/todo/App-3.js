
import React from 'react';

// 
// Nimi:
// OpNro:
//


// const App = () => {
//     const kurssi = 'Half Stack -sovelluskehitys'
//     const osa1 = {
//       nimi: 'Reactin perusteet',
//       tehtavia: 10
//     }
//     const osa2 = {
//       nimi: 'Tiedonvälitys propseilla',
//       tehtavia: 7
//     }
//     const osa3 = {
//       nimi: 'Komponenttien tila',
//       tehtavia: 14
//     }

//     return (
//       <div>
//         ...
//       </div>
//     )
//   }



export default App

