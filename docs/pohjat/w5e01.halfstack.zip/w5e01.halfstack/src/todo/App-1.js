
import React from 'react';


// 
// Nimi:
// OpNro:
//


// const App = () => {
//     // const-määrittelyt

//     return (
//         <div>
//             <Otsikko kurssi={kurssi} />
//             <Sisalto ... />
//             <Yhteensa ... />
//         </div>
//     )
// }


export default App

