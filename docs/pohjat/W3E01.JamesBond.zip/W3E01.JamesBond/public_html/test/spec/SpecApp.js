
/* global expect, OPISKELIJA */

var
        APP = 'BondApp',
        CONTROLLER = 'BondController',
        TEMPLATE = '../todo/template.html';

describe(APP + ' / ' + OPISKELIJA.nimi, function () {

    var templateHtml;

    beforeAll(function () {
        templateHtml = $.ajax(TEMPLATE, {async: false}).responseText;
    });

    describe('template', function () {
        it('sisältää oletetut elementit', function () {
            var template = $(templateHtml);
            expect(template.find('h1').length).toBe(1);
            expect(template.find('div>label>input').length).toBe(2);
            expect(template.find('*').length).toBe(7);
        });
    });

    describe('view', function () {

        var scope, controller, template;


        beforeEach(function () {

            module(APP);

            inject(function ($compile, $rootScope, $controller) {

                scope = $rootScope.$new();
                template = $compile($(templateHtml))(scope);
                controller = $controller(CONTROLLER, {
                    $scope: scope
                });
            });

        });


        it('alustaa otsikon James Bondilla', function () {

            scope.$digest();

            var otsikko = template.find('h1').text();

            expect(otsikko).toBe('My name is Bond, James Bond');
        });

        it('alustaa tekstikentät James Bondilla', function () {

            scope.$digest();

            var etunimi = template.find('#etunimi').val();
            var sukunimi = template.find('#sukunimi').val();

            expect(etunimi).toBe('James');
            expect(sukunimi).toBe('Bond');
        });


        it('esittää kenttiin syötetyt arvot otsikossa', function () {

            template.find('#etunimi').val('Bart').trigger('input');
            template.find('#sukunimi').val('Simpson').trigger('input');

//            console.log(scope.etunimi);
//            console.log(scope.sukunimi);

            var otsikko = template.find('h1').text();

            expect(otsikko).toBe('My name is Simpson, Bart Simpson');
        });

    });

});

