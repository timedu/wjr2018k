
//
var OPISKELIJA = {
    nimi: 'N.N.',
    numero: '999999'
};
//

var BondApp = angular.module('BondApp', []);

BondApp.controller('BondController', function ($scope) {


});
